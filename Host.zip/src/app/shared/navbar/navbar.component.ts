import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import './navbar.html';
@Component({
    selector: 'as-navbar',
    template: require('./navbar.html'),
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class NavbarComponent {
    @Input() brand: string;
}
