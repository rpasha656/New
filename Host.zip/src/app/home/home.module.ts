import { NgModule } from '@angular/core';
import { HomeComponent } from './index';

@NgModule({
    declarations: [
        HomeComponent
    ],
    exports: [
        HomeComponent
    ]
})
export class HomeModule {
}
